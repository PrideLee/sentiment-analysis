import os
import pickle



class DataPreprocess(object):
    def __init__(self, args):
        self.data_path = args.data_path
        pass
