import argparse
import tensorflow as tf
import pickle
import os
import time
import math
import warnings

warnings.filterwarnings('ignore')

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


class PreData(object):
    def __init__(self, args, data):
        self.batch_size = args.batch_size
        self.epoch = args.epoch
        self.lr = args.lr
        self.max_len = data.max_len
        self.half_window = args.half_window
        self.embed_dim = args.embed_dim
        self.vocab_size = data.vocab_size
        self.num_sampled = args.num_sampled
        self.model_path = args.model_path
        self.data_path = args.data_path
        self.lookup_table_path = args.lookup_table_path
        self.pretrain_data_path = args.pretrain_data_path
        self.raw_data = data
        self.data = list()
        self.label = list()
        self.load_data_mode = args.load_data_mode

        # add placeholder
        self.x = tf.placeholder(shape=[None, self.half_window * 2], dtype=tf.int32, name='x')
        self.y = tf.placeholder(shape=[None, 1], dtype=tf.int32, name='y')

        # load_data
        if self.load_data_mode:
            self.__load_data()
        else:
            self.__build_data()

        self.__build_graph()

    def __build_graph(self):
        self.lookup_table = tf.Variable(
            tf.random_uniform(shape=[self.vocab_size, self.embed_dim], minval=-1.0, maxval=1.0))

        softmax_weights = tf.Variable(
            tf.truncated_normal(shape=(self.vocab_size, self.embed_dim), stddev=1.0 / math.sqrt(self.embed_dim)))
        softmax_biases = tf.Variable(tf.zeros(shape=(self.vocab_size), dtype=tf.float32))

        # word_embedding
        with tf.variable_scope("word_embdding"):
            self.embedding = tf.nn.embedding_lookup(self.lookup_table,
                                                    self.x)  # shapae = [batch_size, seq_len, embed_dim]
            self.embedding = tf.reduce_sum(self.embedding, 1)  # shape = [batch_size, embed_dim]

            self.loss = tf.reduce_mean(
                tf.nn.sampled_softmax_loss(
                    weights=softmax_weights,
                    biases=softmax_biases,
                    labels=self.y,
                    inputs=self.embedding,
                    num_sampled=self.num_sampled,
                    num_classes=self.vocab_size))

            self.train_step = tf.train.AdamOptimizer(self.lr).minimize(self.loss)

    def train(self):
        if not os.path.exists(self.model_path):
            os.makedirs(self.model_path)
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            saver = tf.train.Saver(max_to_keep=1)
            for epoch in range(self.epoch):
                # self.pointer = 0
                self.run_one_epoch(sess, saver, epoch)
                step_num = epoch * self.batch_size
                saver.save(sess, self.model_path, global_step=step_num)

            lookup_table = sess.run(self.lookup_table)
            with open(self.lookup_table_path, 'wb') as f:
                pickle.dump(lookup_table, f)

    def run_one_epoch(self, sess, saver, epoch):
        train_size = len(self.data)
        batch_num = int(train_size // self.batch_size)
        for i in range(batch_num):
            b = self.batch_size * i
            e = min(self.batch_size * (i + 1), train_size)
            try:
                loss, _ = sess.run([self.loss, self.train_step],
                                   feed_dict={self.x: self.data[b:e], self.y: self.label[b:e]})
            except Exception as error:
                print(error)
                continue

            if i % 1000 == 0:
                print("epoch {}, batch {}, loss: {}".format(epoch, i, loss))

    def __build_data(self):
        raw_data_list = self.raw_data.data_id
        seq_len = self.raw_data.seq_len
        for i, raw_data in enumerate(raw_data_list):
            for index in range(0, seq_len[i]):
                self.label.append([raw_data[index]])
                data = list()
                for i in range(index - self.half_window, index + self.half_window):
                    try:
                        data.append(raw_data[i])
                    except Exception as e:
                        data.append(0)
                self.data.append(data)

        with open(self.pretrain_data_path, 'wb') as f:
            pickle.dump([self.data, self.label], f)

    def __load_data(self):
        with open(self.pretrain_data_path, 'rb') as f:
            load_data = pickle.load(f)
            self.data = load_data[0]
            self.label = load_data[1]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=500)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--half_window', type=int, default=3)
    parser.add_argument('--embed_dim', type=int, default=128)
    parser.add_argument('--num_sampled', type=int, default=100)
    parser.add_argument('--model_path', type=str, default="./model/model")
    parser.add_argument('--data_path', type=str, default="pkl/data.pkl")
    parser.add_argument('--pretrain_data_path', type=str, default="pkl/pretrain_data.pkl")
    parser.add_argument('--load_data_mode', type=bool, default=1,
                        help='load data or generate data')
    parser.add_argument('--lookup_table_path', type=str, default="pkl/lookup_table.pkl", )
    parser.add_argument('--class_num', type=int, default=2)
    args = parser.parse_args()

    with open(args.data_path, 'rb') as f:
        data = pickle.load(f)

    start = time.time()
    print("start training")
    print("#" * 50)
    model = PreData(args, data)
    model.train()

    print("finished")
    print("#" * 50)

    end = time.time()

    print("total training time: {}".format(end - start))
