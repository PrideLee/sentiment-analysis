import os
import argparse
import pickle


class DataProcess(object):
    def __init__(self, args):
        self.train_path = args.train_path
        self.test_path = args.test_path
        self.vocab_file = args.vocab_file
        self.data_id = list()
        self.label_id = list()
        self.seq_len = list()
        self.vocab_dict = dict()
        self.max_len = 500
        self.label_cnt = args.class_num

        self.__build_vocab()
        self.__build_dict(os.path.join(self.train_path, "pos"), 0)
        self.__build_dict(os.path.join(self.train_path, "neg"), 1)
        self.__build_dict(os.path.join(self.test_path, "pos"), 0)
        self.__build_dict(os.path.join(self.test_path, "neg"), 1)

    def __build_vocab(self):
        self.vocab_dict["<PAD>"] = 0
        self.vocab_dict["<UKN>"] = 0
        cnt = 1
        with open(self.vocab_file, 'rb') as f:
            while (True):
                line = f.readline().decode('utf-8').strip('\n')
                if not line:
                    break
                self.vocab_dict[line] = cnt
                cnt += 1
        self.vocab_size = len(self.vocab_dict)

    def __build_dict(self, path, label):
        '''
        :param path:   文件路径
        :param label:   标签: neg(0) or pos(1)
        :param flag:    flag = 0，表示训练集数据， flag = 1，表示为测试集数据
        :return:
        '''
        if not os.path.exists(path):
            print("Data path does not exist!")
            return
        files = os.listdir(path)
        for file in files:  # 遍历文件夹
            file = os.path.join(path, file)
            with open(file, 'rb') as f:
                line = f.readline().decode('utf-8')
                line = line.replace('<br />', '').split()
                seq_length = min(self.max_len, len(line))
                self.seq_len.append(seq_length)
                data = list()
                for i in range(self.max_len):
                    try:
                        data.append(self.vocab_dict[line[i].lower()])
                    except Exception as e:
                        data.append(self.vocab_dict['<UKN>'])
                self.label_id.append(self.__int2one_hot(label))
                self.data_id.append(data)
        self.total_seq_num = len(self.label_id)

    def __int2one_hot(self, id):
        one_hot = [0] * self.label_cnt
        one_hot[id] = 1
        return one_hot

    def make_data(self):
        # data = DataProcess(args)
        data_output = open('data.pkl', 'wb')
        pickle.dump(self, data_output)
        data_output.close()

        # rb 以二进制读取
        # data_input = open('data.pkl', 'rb')
        # read_data = pickle.load(data_input)
        # data_input.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_path', type=str, default='./data/data/train')
    parser.add_argument('--test_path', type=str, default='./data/data/test')
    parser.add_argument('--vocab_file', type=str, default='./data/data/imdb.vocab')
    parser.add_argument('--class_num', type=int, default=2)
    args = parser.parse_args()

    model = DataProcess(args)
    # model.make_data()
    a = 1
