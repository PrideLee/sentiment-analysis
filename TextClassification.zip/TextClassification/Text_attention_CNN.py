import tensorflow as tf
import argparse
from TextCNN_Preprocess import DataProcess
import os
import pickle
from sklearn.model_selection import train_test_split


class TextAttentionCNN(object):
    def __init__(self, args, data):
        self.mode = args.mode
        self.lr = args.lr
        self.epoch = args.epoch
        self.batch_size = args.batch_size
        self.word_dim = args.word_dim
        self.data = data.data_id
        self.label = data.label_id
        self.max_len = data.max_len
        self.label_cnt = data.label_cnt  # 标签类别数
        self.vocab_size = data.vocab_size
        self.seq_num = data.total_seq_num
        self.test_size = args.test_size
        self.valid_size = args.valid_size
        self.keep_prob = args.keep_prob
        self.l2_lambda = args.l2_lambda
        self.model_dir = 'attention_CNN_model'
        self.graph_dir = 'attention_CNN_graph'
        self.saved_data = args.saved_data
        self.no_improvement_in_n = args.no_improvement_in_n
        self.word_hidden_dim = args.word_hidden_dim
        self.filter_num = args.filter_num
        self.filter_sizes = [3, 4, 5]

        # add placeholder
        self.x = tf.placeholder(shape=[None, self.max_len], dtype=tf.int32, name='x')
        self.y = tf.placeholder(shape=[None, self.label_cnt], dtype=tf.float32, name='y')

        with tf.variable_scope("lookup_table"):
            look_up_table = tf.Variable(tf.truncated_normal(shape=(self.vocab_size, self.word_dim),
                                                            mean=0,
                                                            stddev=0.1),
                                        name='look_up_table')

            self.embeddings = tf.nn.embedding_lookup(look_up_table, self.x)  # shape=[batch_size, max_len, word_dim]
            # self.embeddings_expand = tf.expand_dims(self.embeddings, -1)

        # train_model
        self.build_graph()
        if self.mode == "train":
            self.train_model()
        elif self.mode == "test":
            self.test()

    def build_graph(self):
        with tf.variable_scope("word_attention"):
            '''双向GRU'''
            # gru word level
            word_cell_fw = tf.nn.rnn_cell.GRUCell(self.word_hidden_dim)
            word_cell_bw = tf.nn.rnn_cell.GRUCell(self.word_hidden_dim)
            # outputs为(output_fw, output_bw)，是一个包含前向cell输出tensor和后向cell输出tensor组成的元组。shape=[batche_size, max_len, word_dim]
            # states为(output_state_fw, output_state_bw)，包含了前向和后向最后的隐藏状态的组成的元组。
            # self.embedding.shape=[batche_size, max_len, word_dim]
            (word_outputs, _) = tf.nn.bidirectional_dynamic_rnn(word_cell_fw,
                                                                word_cell_bw,
                                                                self.embeddings,
                                                                dtype=tf.float32)
            word_outputs = tf.concat(word_outputs, 2)  # shape = [batch_size, max_len, word_hidden_dim*2]
            word_outputs_ = tf.reshape(word_outputs,
                                       [-1,
                                        self.word_hidden_dim * 2])  # shape = [batch_size*max_len, word_hidden_dim*2]

            '''词级别的attention机制'''
            # attention layer
            w_word_attention = tf.Variable(
                tf.truncated_normal(shape=[self.word_hidden_dim * 2, self.word_hidden_dim * 2],
                                    mean=0,
                                    stddev=0.1),
                name='weight_word_attention')
            b_word_attention = tf.Variable(tf.zeros(shape=[self.word_hidden_dim * 2]),
                                           name='bias')

            hidden_representation = tf.nn.tanh(
                tf.matmul(word_outputs_, w_word_attention) + b_word_attention)  # shape=[batch_size*maxlen, word_dim*2]
            hidden_representation = tf.reshape(hidden_representation, [-1, self.max_len, self.word_hidden_dim * 2])

            # 随机初始化的上下文向量w_context_similarity
            word_context_similarity = tf.Variable(tf.truncated_normal(shape=[self.word_hidden_dim * 2],
                                                                      mean=0,
                                                                      stddev=0.1),
                                                  name='word_context_similarity')

            # 1) get logits for each word in the sentence
            hidden_state_context_similarity = tf.multiply(hidden_representation,
                                                          word_context_similarity)  # shape=[batch_size, max_len, word_hidden_dim]
            attention_logits = tf.reduce_sum(hidden_state_context_similarity, 2)  # shape=[batch_size, max_len]
            attention_logits_max = tf.reduce_max(attention_logits, 1, keepdims=True)  # shape=[batch_size, 1]

            # 2) get possibility distribution for each word in the sentence.
            p_attention = tf.nn.softmax(
                attention_logits - attention_logits_max)  # shape:[batch_size,max_len]

            # 3) get weighted hidden state by attention vector
            p_attention_expanded = tf.expand_dims(p_attention,
                                                  axis=2)  # shape:[batch_size,max_len,1]

            sentence_representation = tf.multiply(p_attention_expanded,
                                                  word_outputs)  # shape:[batch_size, max_len, word_hidden_dim*2]
            sentence_representation_expand = tf.expand_dims(sentence_representation, -1)

            '''multiple CNN layers'''
            pooled_outputs = list()
            for i, filter_size in enumerate(self.filter_sizes):
                with tf.variable_scope('graph'):
                    # 卷积层1
                    weight1 = tf.Variable(
                        tf.truncated_normal(shape=[filter_size, self.word_hidden_dim * 2, 1, self.filter_num],
                                            mean=0,
                                            stddev=0.1),
                        name='weight1')
                    bias1 = tf.Variable(tf.zeros(shape=[self.filter_num]), name='bias1')
                    conv1 = tf.nn.relu(tf.nn.conv2d(sentence_representation_expand,
                                                    weight1,
                                                    strides=[1, 1, 1, 1],
                                                    padding='VALID',
                                                    name='conv1')
                                       + bias1)  # shape = [batch_size, max_len-filter_size+1, 1, filter_num]
                    out_size = self.max_len - filter_size + 1
                    conv1 = tf.reshape(conv1, [-1, out_size, self.filter_num, 1])

                    # 卷积层2
                    weight2 = tf.Variable(tf.truncated_normal(shape=[filter_size, self.filter_num, 1, self.filter_num],
                                                              mean=0,
                                                              stddev=0.1),
                                          name='weight2')
                    bias2 = tf.Variable(tf.zeros(shape=[self.filter_num]), name='bias2')
                    conv2 = tf.nn.relu(tf.nn.conv2d(conv1,
                                                    weight2,
                                                    strides=[1, 1, 1, 1],
                                                    padding='VALID',
                                                    name='conv2')
                                       + bias2)  # shape = [batch_size, out_size-filter_size+1, 1, filter_num]

                    h = tf.nn.max_pool(conv2,
                                       ksize=[1, out_size - filter_size + 1, 1, 1],
                                       strides=[1, 1, 1, 1],
                                       padding='VALID',
                                       name='h')
                    pooled_outputs.append(h)

            total_filter_num = self.filter_num * len(self.filter_sizes)
            h_pool = tf.concat(pooled_outputs, 3)

            # 全连接层
            with tf.variable_scope("full_connection"):
                h_pool_flat = tf.reshape(h_pool, [-1, total_filter_num])
                h_drop = tf.nn.dropout(h_pool_flat, self.keep_prob)
                w_fc = tf.Variable(tf.truncated_normal(shape=[total_filter_num, self.label_cnt],
                                                       mean=0,
                                                       stddev=0.01),
                                   name='w_fc')
                b_fc = tf.Variable(tf.zeros(shape=[self.label_cnt]), name='b_fc')
                self.logits = tf.nn.relu(tf.matmul(h_drop, w_fc) + b_fc)

        # loss
        loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.y))
        for v in tf.trainable_variables():
            if 'bias' not in v.name:
                l2_loss = tf.add_n([tf.nn.l2_loss(v)]) * self.l2_lambda
        self.loss = l2_loss + loss
        self.train_step = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
        self.precision = tf.equal(tf.argmax(self.logits, 1), tf.argmax(self.y, 1))
        self.accuracy = tf.reduce_mean(tf.cast(self.precision, tf.float32))

    def train_model(self):
        with tf.Session() as sess:
            tf.summary.FileWriter(self.graph_dir, sess.graph)
            saver = tf.train.Saver(max_to_keep=1)
            if not os.path.exists(self.model_dir):
                os.makedirs(self.model_dir)
            model_save = os.path.join(self.model_dir, 'my_model')

            sess.run(tf.global_variables_initializer())
            temp_data, test_data, temp_label, test_label = train_test_split(self.data, self.label,
                                                                            test_size=self.test_size)
            train_data, valid_data, train_label, valid_label = train_test_split(temp_data, temp_label,
                                                                                test_size=self.valid_size)

            test = [test_data, test_label]
            data_output = open(os.path.join(self.saved_data, '/test_data.pkl'), 'wb')
            pickle.dump(test, data_output)
            data_output.close()

            print("数据集大小：")
            print("-训练集：{}".format(len(train_label)))
            print("-测试集：{}".format(len(test_label)))
            print("-校验集：{}".format(len(valid_label)))
            valid_loss = 1e5
            valid_cnt = 0
            for epoch in range(self.epoch):
                self.train_one_epoch(sess, saver, epoch, train_data, train_label)
                step_num = epoch * self.batch_size
                saver.save(sess, model_save, global_step=step_num)

                # 验证集上准确度连续下降n次，提前终止训练
                temp_loss, temp_accuracy = sess.run([self.loss, self.accuracy],
                                                    feed_dict={self.x: valid_data, self.y: valid_label})
                print(" validation loss:{}, validation accuracy:{}".format(temp_loss, temp_accuracy))
                print("*" * 50)
                if temp_loss > valid_loss:
                    valid_cnt += 1
                    valid_loss = temp_loss
                    if valid_cnt >= self.no_improvement_in_n:
                        break
                else:
                    valid_cnt = 0
            # 测试集
            # loss, accuracy = sess.run([self.loss, self.accuracy],
            #                           feed_dict={self.x: test_data, self.y: test_label})
            # print("test loss: {}, test accuracy: {}".format(loss, accuracy))

    def train_one_epoch(self, sess, saver, epoch, train_data, train_label):
        self.pointer = 0
        num_batches = int(
            (self.seq_num * (
                    1 - self.test_size - self.valid_size) + self.batch_size - 1) // self.batch_size)
        for i in range(num_batches):
            try:
                b = self.pointer * self.batch_size
                e = min((self.pointer + 1) * self.batch_size, self.seq_num)
                loss, _, accuracy = sess.run([self.loss, self.train_step, self.accuracy],
                                             feed_dict={self.x: train_data[b: e],
                                                        self.y: train_label[b: e]})
                if i % 50 == 0:
                    print("epoch {}, batch {}, loss: {}, accuracy: {}".format(epoch, i, loss, accuracy))
                self.pointer += 1
            except Exception as e:
                print(e)
                break

    def test(self):
        with tf.Session() as sess:
            saver = tf.train.Saver()
            ckpt_file = tf.train.latest_checkpoint(self.model_dir)
            saver.restore(sess, ckpt_file)

            data_input = open(os.path.join(self.saved_data, 'test_data.pkl'), 'rb')
            data = pickle.load(data_input)
            data_input.close()

            loss, accuracy = sess.run([self.loss, self.accuracy],
                                      feed_dict={self.x: data[0], self.y: data[1]})
            print("test loss: {}, test accuracy: {}".format(loss, accuracy))
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='./train_data.txt')
    parser.add_argument('--mode', type=str, default='train')
    parser.add_argument('--model_dir', type=str, default='./trainsformer_model')
    parser.add_argument('--epoch', type=int, default=50)
    parser.add_argument('--batch_size', type=int, default=200)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--word_dim', type=int, default=100)  # 200
    parser.add_argument('--test_size', type=float, default=0.2)
    parser.add_argument('--valid_size', type=float, default=0.2)
    parser.add_argument('--keep_prob', type=float, default=0.5)
    parser.add_argument('--l2_lambda', type=float, default=1e-2)
    parser.add_argument('--word_hidden_dim', type=int, default=128)
    parser.add_argument('--no_improvement_in_n', type=int, default=5,
                        help='early stop while there is no improvement in n times')

    args = parser.parse_args()

    data = DataProcess(args.data_path)
    model = TextAttention(args, data)
    model.build_graph()
    model.train_model()


if __name__ == "__main__":
    main()
