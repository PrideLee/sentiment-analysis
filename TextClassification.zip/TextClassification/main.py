import argparse
from TextCNN_model import TextCNN_model
# from TextCNN_model2 import TextCNN_model2
# from TextCNN_Preprocess import DataProcess
from Text_preprocess import DataProcess
from Text_attention import TextAttention
from Text_attention_CNN import TextAttentionCNN
import pickle
import os
import time

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

parser = argparse.ArgumentParser()
parser.add_argument('--data_path', type=str, default='./train_data.txt')
parser.add_argument('--mode', type=str, default='train')  # train/ test
parser.add_argument('--model_dir', type=str, default='./attention_model')
parser.add_argument('--graph_dir', type=str, default='./attention_graph')
parser.add_argument('--epoch', type=int, default=5)
parser.add_argument('--batch_size', type=int, default=200)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--word_dim', type=int, default=128)  # 200
parser.add_argument('--test_size', type=float, default=0.05)
parser.add_argument('--valid_size', type=float, default=0.05)
parser.add_argument('--filter_num', type=int, default=10)  # 20
parser.add_argument('--keep_prob', type=float, default=1e-3)
parser.add_argument('--l2_lambda', type=float, default=1e-3)
parser.add_argument('--no_improvement_in_n', type=int, default=5,
                    help='early stop while there is no improvement in n times')
parser.add_argument('--word_hidden_dim', type=int, default=64,
                    help='word hidden dimension in attension model')

# imdb训练集数据处理
parser.add_argument('--train_path', type=str, default='./data/data/train')
parser.add_argument('--test_path', type=str, default='./data/data/test')
parser.add_argument('--vocab_file', type=str, default='./data/data/imdb.vocab')
parser.add_argument('--saved_data', type=str, default='bin_data')
parser.add_argument('--class_num', type=int, default=2)
args = parser.parse_args()

print("start")
print("*" * 50)

flag = 0
if flag:
    data = DataProcess(args)
    data.make_data()
else:
    start = time.time()
    data_input = open('bin_data/data.pkl', 'rb')
    data = pickle.load(data_input)
    data_input.close()
    model = TextAttention(args, data)
    end = time.time()
    print("\n")
    print("total {} time:{}".format(args.mode, end - start))

print("*" * 50)
print("finished")
