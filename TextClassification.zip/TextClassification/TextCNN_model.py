import tensorflow as tf
from sklearn.model_selection import train_test_split
import math
import os


class TextCNN_model(object):
    def __init__(self, args, data):
        self.lr = args.lr
        self.epoch = args.epoch
        self.batch_size = args.batch_size
        self.word_dim = args.word_dim
        self.data = data.data_id
        self.label = data.label_id
        self.max_len = data.max_len
        self.label_cnt = data.label_cnt  # 标签类别数
        self.vocab_size = data.vocab_size
        self.total_seq_num = data.total_seq_num
        self.test_size = args.test_size
        self.valid_size = args.valid_size
        self.filter_sizes = [3, 5, 7]
        self.filter_num = args.filter_num
        self.keep_prob = args.keep_prob
        self.l2_lambda = args.l2_lambda
        self.model_dir = args.model_dir
        self.no_improvement_in_n = args.no_improvement_in_n

        # add placeholder
        self.x = tf.placeholder(shape=(None, self.max_len), dtype=tf.int32, name='input_data')
        self.y = tf.placeholder(shape=(None, self.label_cnt), dtype=tf.float32, name='label')

        # lookup layer
        with tf.variable_scope("embeddings"):
            look_up_table = tf.Variable(tf.truncated_normal(shape=(self.vocab_size, self.word_dim),
                                                            mean=0,
                                                            stddev=0.1),
                                        name='look_up_table')

            self.embeddings = tf.nn.embedding_lookup(look_up_table, self.x)
            self.embeddings_expand = tf.expand_dims(self.embeddings, -1)

    def build_graph(self):
        pooled_outputs = list()
        for i, filter_size in enumerate(self.filter_sizes):
            with tf.variable_scope('graph'):
                # 卷积层1
                weight1 = tf.Variable(tf.truncated_normal(shape=[filter_size, self.word_dim, 1, self.filter_num],
                                                          mean=0,
                                                          stddev=0.1),
                                      name='weight1')
                bias1 = tf.Variable(tf.zeros(shape=[self.filter_num]), name='bias1')
                conv1 = tf.nn.relu(tf.nn.conv2d(self.embeddings_expand,
                                                weight1,
                                                strides=[1, 1, 1, 1],
                                                padding='VALID',
                                                name='conv1')
                                   + bias1)  # shape = [batch_size, max_len-filter_size+1, 1, filter_num]
                out_size = self.max_len - filter_size + 1
                conv1 = tf.reshape(conv1, [-1, out_size, self.filter_num, 1])

                # 卷积层2
                weight2 = tf.Variable(tf.truncated_normal(shape=[filter_size, self.filter_num, 1, self.filter_num],
                                                          mean=0,
                                                          stddev=0.1),
                                      name='weight2')
                bias2 = tf.Variable(tf.zeros(shape=[self.filter_num]), name='bias2')
                conv2 = tf.nn.relu(tf.nn.conv2d(conv1,
                                                weight2,
                                                strides=[1, 1, 1, 1],
                                                padding='VALID',
                                                name='conv2')
                                   + bias2)  # shape = [batch_size, out_size-filter_size+1, 1, filter_num]

                h = tf.nn.max_pool(conv2,
                                   ksize=[1, out_size - filter_size + 1, 1, 1],
                                   strides=[1, 1, 1, 1],
                                   padding='VALID',
                                   name='h')
                pooled_outputs.append(h)

        total_filter_num = self.filter_num * len(self.filter_sizes)
        h_pool = tf.concat(pooled_outputs, 3)

        # 全连接层
        h_pool_flat = tf.reshape(h_pool, [-1, total_filter_num])
        h_drop = tf.nn.dropout(h_pool_flat, self.keep_prob)
        w_fc = tf.Variable(tf.truncated_normal(shape=[total_filter_num, self.label_cnt],
                                               mean=0,
                                               stddev=0.01),
                           name='w_fc')
        b_fc = tf.Variable(tf.zeros(shape=[self.label_cnt]), name='b_fc')
        fc = tf.nn.relu(tf.matmul(h_drop, w_fc) + b_fc)
        y_ = tf.nn.softmax(fc)
        return y_

    def train_model(self):
        y_ = self.build_graph()
        self.loss = tf.reduce_mean(-self.y * tf.log(y_))
        for v in tf.trainable_variables():
            if 'bias' not in v.name:
                l2_loss = tf.add_n([tf.nn.l2_loss(v)]) * self.l2_lambda
        self.loss += l2_loss
        self.train_step = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
        precision = tf.equal(tf.arg_max(y_, 1), tf.arg_max(self.y, 1))
        self.accuracy = tf.reduce_mean(tf.cast(precision, tf.float32))

        with tf.Session() as sess:
            tf.summary.FileWriter('graph', sess.graph)
            saver = tf.train.Saver(max_to_keep=1)
            if not os.path.exists(self.model_dir):
                os.makedirs(self.model_dir)
            model_save = os.path.join(self.model_dir, 'my_model')

            sess.run(tf.global_variables_initializer())
            temp_data, test_data, temp_label, test_label = train_test_split(self.data, self.label,
                                                                            test_size=self.test_size)
            train_data, valid_data, train_label, valid_label = train_test_split(temp_data, temp_label,
                                                                                test_size=self.valid_size)
            print("数据集大小：")
            print("-训练集：{}".format(len(train_label)))
            print("-测试集：{}".format(len(test_label)))
            print("-校验集：{}".format(len(valid_label)))
            valid_loss = 1e5
            valid_cnt = 0
            for epoch in range(self.epoch):
                self.train_one_epoch(sess, saver, epoch, train_data, train_label)
                step_num = epoch * self.batch_size
                saver.save(sess, model_save, global_step=step_num)

                # 验证集上准确度连续下降n次，提前终止训练
                temp_loss, temp_accuracy = sess.run([self.loss, self.accuracy],
                                                    feed_dict={self.x: valid_data, self.y: valid_label})
                print(" validation loss:{}, validation accuracy:{}".format(temp_loss, temp_accuracy))
                print("*" * 50)
                if temp_loss > valid_loss:
                    vilid_cnt += 1
                    valid_loss = temp_loss
                    if valid >= self.no_improvement_in_n:
                        break
                else:
                    valid_cnt = 0

            # 测试集
            loss, accuracy = sess.run([self.loss, self.accuracy],
                                      feed_dict={self.x: test_data, self.y: test_label})
            print("test loss: {}, test accuracy: {}".format(loss, accuracy))

    def train_one_epoch(self, sess, saver, epoch, train_data, train_label):
        self.pointer = 0
        num_batches = int(
            (self.total_seq_num * (1 - self.test_size - self.valid_size) + self.batch_size - 1) // self.batch_size)
        for i in range(num_batches):
            try:
                b = self.pointer * self.batch_size
                e = min((self.pointer + 1) * self.batch_size, self.total_seq_num)
                loss, _, accuracy = sess.run([self.loss, self.train_step, self.accuracy],
                                             feed_dict={self.x: train_data[b: e], self.y: train_label[b: e]})
                if i % 50 == 0:
                    print("epoch {}, batch {}, loss: {}, accuracy: {}".format(epoch, i, loss, accuracy))
                self.pointer += 1
            except Exception as e:
                print(e)
                break
