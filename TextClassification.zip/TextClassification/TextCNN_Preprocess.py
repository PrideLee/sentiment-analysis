import os


class DataProcess(object):
    def __init__(self, data_path):
        self.data_path = data_path
        self.data = list()
        self.label = list()
        self.data_vocab = dict()
        self.label_vocab = dict()
        self.data_id = list()
        self.label_id = list()
        self.max_len = 100
        self.vocab_size = 0
        self.total_seq_num = 0
        self.cnt = 0
        # 数据预处理
        self.build_dict()
        self.build_vocab()
        self.word2id()


    def build_dict(self):
        if not os.path.exists(self.data_path):
            print("Data path does not exist!")
            return
        with open(self.data_path, 'rb') as f:
            while (True):
                line = f.readline().decode('utf-8')
                if not line:
                    break
                line = line.strip('\t').split()
                try:
                    self.label.append(line[0])
                    self.data.append(line[1:-1])
                    if len(line) > self.max_len:
                        self.cnt += 1
                        # self.max_len = len(line)
                except Exception as e:
                    print(e)
                    continue
            self.total_seq_num = len(self.data)

    def build_vocab(self):
        self.data_vocab['<PAD>'] = 0
        label_value = 0
        data_value = 1
        for i in range(len(self.label)):
            if self.label[i] not in self.label_vocab.keys():
                self.label_vocab[self.label[i]] = label_value
                label_value += 1
            for j in range(len(self.data[i])):
                if self.data[i][j] not in self.data_vocab.keys():
                    self.data_vocab[self.data[i][j]] = data_value
                    data_value += 1
        self.vocab_size = len(self.data_vocab)

    def word2id(self):
        data_id = list()
        for i in range(len(self.label)):
            one_hot = self.int2one_hot(self.label_vocab[self.label[i]])
            self.label_id.append(one_hot)
            for j in range(self.max_len):
                if j < len(self.data[i]):
                    data_id.append(self.data_vocab[self.data[i][j]])
                else:
                    data_id.append(self.data_vocab['<PAD>'])
            self.data_id.append(data_id)
            data_id = []

    def int2one_hot(self, id):
        one_hot = [0] * len(self.label_vocab)
        one_hot[id] = 1
        return one_hot



data_path = "./train_data.txt"
if __name__ == '__main__':
    test = DataProcess(data_path)
    a = 1
